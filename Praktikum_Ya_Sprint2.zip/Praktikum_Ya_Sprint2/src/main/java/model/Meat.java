package model;

public abstract class Meat extends Food {

    private boolean isVegetarian;

    public Meat(int amount, double price, boolean isVegetarian) {
        super(amount, price, true);
    }

    @Override
    public int getDiscount() {
        return 0;
    }
    }
