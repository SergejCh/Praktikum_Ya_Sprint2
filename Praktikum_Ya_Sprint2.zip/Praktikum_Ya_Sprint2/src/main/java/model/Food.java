package model;

	public abstract class Food implements Discountable {

		protected final int amount;
		protected final double price;
		private final boolean isVegatarian;

		public Food(int amount, double price, boolean isVegatarian) {
			this.amount = amount;
			price = price;
			this.isVegatarian = isVegatarian;
		}

		public double getTotalPrice() {
			return amount * price;
		}

		public double getTotalPriceWithDiscount() {
			return getTotalPrice() * (100 - getDiscount()) / 100.0;
		}

		public double getTotalPriceForCrewed() {
			return isVegatarian ? getTotalPrice() : 0;
		}

}
