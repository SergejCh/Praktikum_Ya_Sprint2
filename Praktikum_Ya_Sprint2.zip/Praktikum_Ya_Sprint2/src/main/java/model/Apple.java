package model;

public abstract class Apple extends Food {

	private boolean isVegetarian;

	public Apple(int amount, double price, boolean isVegetarian) {
		super(amount, price, true);
	}

	@Override
	public int getDiscount() {
		return 0;
	}
}
