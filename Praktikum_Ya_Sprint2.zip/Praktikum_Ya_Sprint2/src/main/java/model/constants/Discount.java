package model.constants;

public class Discount {
    int getDiscount(){
        return 0;
    }
}
