package model.constants;

public class Colour {
    public static final String colour = null;
}
