package model.service;

import model.Food;

public class ShoppingCart {
    public ShoppingCart(Food[] products) {
    }

    public String totalPriceWithoutDiscount() {
        return
    }

    public String totalPriceVegatarian() {
        return
    }

    public String totalPriceWithDiscount() {
        return
    }
}
