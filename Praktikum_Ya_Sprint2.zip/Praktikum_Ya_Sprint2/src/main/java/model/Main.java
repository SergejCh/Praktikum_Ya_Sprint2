package model;

import model.service.ShoppingCart;

public class Main {

    private static final Object COLOUR_RED = null;
    private static final Object COLOUR_GREEN = null;
    private static int amount;
    private static Object price;

    public static void main(String[] args) {
        Meat meat = new Meat(5, price: 100);
        Apple redApple = new Apple(amount: 10, price: 50, COLOUR_RED);
        Apple greenApple = new Apple(amount: 8, price: 60, COLOUR_GREEN);
        Food[] products = new Food[]{meat, redApple, greenApple};
        ShoppingCart shoppingCart = new ShoppingCart(products);
        System.out.println("Общая сумма товаров без скидки " + shoppingCart.totalPriceWithDiscount());
        System.out.println("Общая сумма товаров со скидкой " + shoppingCart.totalPriceWithoutDiscount());
        System.out.println("Сумма всех вегетарианских товаров без скидки " + shoppingCart.totalPriceVegatarian());

    }
}
