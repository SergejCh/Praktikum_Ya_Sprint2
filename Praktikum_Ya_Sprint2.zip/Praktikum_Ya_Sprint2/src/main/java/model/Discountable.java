package model;

public interface Discountable {
    int getDiscount(){
        return 0;
    }
}
